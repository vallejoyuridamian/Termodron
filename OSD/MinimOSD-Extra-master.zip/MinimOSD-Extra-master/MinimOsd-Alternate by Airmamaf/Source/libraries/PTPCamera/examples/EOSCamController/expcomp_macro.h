extern EEPROMByteList          vlExpCompensation;

#define EXP_COMP_VALUE(i)((uint32_t)vlExpCompensation.Get((i)))
